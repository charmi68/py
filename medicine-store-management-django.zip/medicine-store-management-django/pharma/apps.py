from django.apps import AppConfig


class PharmaConfig(AppConfig):
    name = 'pharma'
